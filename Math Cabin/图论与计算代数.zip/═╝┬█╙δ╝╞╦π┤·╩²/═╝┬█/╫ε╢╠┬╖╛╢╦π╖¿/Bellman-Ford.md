与迪克斯特拉算法不同的是，不再去宽度优先遍历那些点，但去遍历每条边，然后看是否更新那边对应的一个顶点到起点的距离。。

# 基本流程
1. 通过遍历每条边，来确定是否更新一个点的$\delta$值(起点到该点目前的最小值)，具体的判断方法是，假设我们取了一条边，记作$(i,j)$,将j记为目标点，那么
$$
\forall (i,j)\in A,\delta(j) = \min\{\delta(i),\delta(i)+m(i,j)\}
$$
2. 将这步重复足够的次数直到得到最后的结果。

	其实核心思想是我们想要创造一条比现在更短的路径，唯一的做法就是往现在的路径中插点，于是我们就检查新插入的路径是否比原来的路径更短，以此判断。

# 代码实现
通常我们需要进行$card(S)-1$次松弛操作，有时比这次数少我们也能直接的出结果。

## Convergence
只有有限个点，有限条边，所以$\delta$的可能值数目是有限的。算法里我们的$\delta$一直减小，，只要进行足够多次的遍历，最后一定会小到那个最小值。

## 代码描述
```
1. Initialiser les valeurs de delta
2. 重复n-1次：
	3. 任意边(i,j)
		4. 更新$\delta(j) = \min\{\delta(j),\delta(i)+m(i,j)\}$
```

## 时间复杂度
### Bellman-Ford
$$
n^{3}
$$
一幅图最多有以下边数：
$$
2\left(
\begin{matrix}
n \\
2
\end{matrix}
\right) = n(n-1)
$$
，而对每条边我们最多都要遍历$n-1$次，所以：
$$
n(n-1)\times (n-1) \sim n^{3}
$$

### Dijkstra
第k步，共有k个sommet被标记，因此最新的那个点最多有$n-k$条边选择，选择下一个未标记点。由此我们可以计算时间复杂度为：
$$
\sum_{k=1}^{n}(n-k) = \frac{n(n-1)}{2}\sim \frac{n^{2}}{2}
$$
## 代码实现
	该算法特点是，写起来简单。但是运算量很大。
```python
import numpy as np
def bellman_ford(M,s0):
	n = len(M)
	Delta = [np.Infinity]*n
	Chemins = [[]]*n
	Delta[s0] = 0
	Chemins[s0] = [s0]
	for k in range(n-1):		 # 规定迭代次数，为 card(S)-1
		for i in range(n):
			for j in range(n):	 # 尝试遍历图中的每条边
				if M[i][j]!=0 and Delta[i]+M[i][j]<Delta[j]:
					Delta[j] = Delta[i]+M[i][j]
					Chemins[j] = Chemins[i] + [j]
	return Delta, Chemins
```

## 特殊功用
利用这个算法，我们可以检测图中是否有circuit absorbant.
事实上，我们已经证明在经过$n-1$次操作后，我们应该已经得出结果了。但是如果我们继续跑算法，发现有的路径值在继续缩小，那么就说明有circuit absorbant存在了。
```python
import numpy as np
def contient_circuit_absorbant(M,s0)：
	n = len(M)
	Delta = [np.Infinity]*n
	Delta[s0] = 0
	for k in range(n-1):
		for i in range(n):
			for j in range(n):
				if M[i][j]!=0 and Delta[i]+M[i][j]<Delta[j]:
					Delta[j] = Delta[i]+M[i][j]
	for i in range(n):
		for j in range(n):
			if M[i][j]!=0 and Delta[i]+M[i][j]<Delta[j]: # 迭代n-1次后结果还会变，说明有诈
					return True
	return False
```

西八啊，老师上课讲的例子太有误导性了喂。