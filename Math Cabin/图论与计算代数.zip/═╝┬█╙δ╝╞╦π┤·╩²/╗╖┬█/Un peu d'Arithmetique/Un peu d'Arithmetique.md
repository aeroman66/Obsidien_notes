# Congrus
	同余
- Theo de Division euclidienne
Soient $a\in \mathbb{Z}$ et $n \in \mathbb{Z}^{*}$ deux entiers relatifs avec $n \ne 0$
$$
\exists ! (q,r)\in \mathbb{Z} \times [0,|n|-1]\cap \mathbb{Z},a = nq+r
$$
On dit que q est le quotient et r le reste de la devision euclidienne de a par n.
- Congrus
Deux entiers relatifs $(a,b)\in\mathbb{Z}^{2}$ sont dits ***condrus module n***（这个包含n的东西是一个完整的关系，n是不能从中割裂出来的）,lorsqu'ils ont le meme reste par la division euclidienne:
$$
\exists (q,q^{'},r) \in \mathbb{Z}^{2}\times [0,|n|-1]\cap \mathbb{Z},
\begin{cases}
a = qn+r \\
b = q^{'}n+r
\end{cases}
$$
On note:
$$
a \equiv b[n]
$$
	不要先入为主，后面括号内的是除数而不是余数。
- Propriete
1. $\forall (a,b) \in \mathbb{Z}^{2},a \equiv b[n] \Leftrightarrow a-b \in n\mathbb{Z}$
2. La relation de congruence module n est une relation d'equivalence.
	主要验证reflexive, symetrie, transtive
3. La classe d'equivalence de a,notee $\dot{a}$:
$$
\dot{a} = \{ b \in \mathbb{Z}|a \equiv b[n] \} = \{ a +qn |q \in \mathbb{Z} \} = a +n\mathbb{Z}
$$
	在 a 的基础上加上余数的整数倍。
4. $\dot{a} = \dot{r}$, r est le reste de la division euclidienne de a par n.
	on a $a \equiv r [n]$, donc $\dot{a} = \dot{r}$ comme relation de congruence module n est une relation d'equivalence.
5. $\forall (a,b)\in \mathbb{Z}^{2}$, la classe d'equivalence de $a+b,\dot{\widehat{a+b}}$ depend seulement de $\dot{a},\dot{b}$
	只要证明$\dot{a},\dot{b}$ 分别相同时，得到的$\dot{\widehat{a+b}}$ 就是相同的，这样就说明与其他的无关了。
# 倍数与因数
## Commun diviseur
Soit $(a,b) \in \mathbb{Z}^{2}$,on pose:
$$
a\mathbb{Z} + b\mathbb{Z} = \{ ka+lb|(k,l)\in \mathbb{Z}^{2} \}
$$
on remarque que $a\mathbb{Z} + b\mathbb{Z}$ est un sous-groupe de $\mathbb{Z}$, donc:
$$
\exists ! d \in \mathbb{N},a\mathbb{Z} + b\mathbb{Z} = d\mathbb{N}
$$
on remarque que:
$$
a\mathbb{Z} \subset d\mathbb{Z},b\mathbb{Z} \subset d\mathbb{Z}
$$
donc d est un diviseur commun de a et b.
	***PGCD*** : Plus Grand Commun Diviseur
### Premiers
Un nombre $p \in \mathbb{N}\backslash \{ 0,1 \}$ est premier loraque ses seuls diviseurs positifs sont 1 et p.
On dit que deux entiers relatifs a et b sont premiers entre eux loraque:
$$
PGCD = (a,b) = 1
$$
## Commun multiple
Soit $(a,b) \in \mathbb{Z}^{2}$,on pose:
$$
d\mathbb{Z} \subset a\mathbb{Z},d\mathbb{Z} \subset a\mathbb{Z}
$$
donc d est un multiple commun de a et b.
	***PPCM*** : Plus Petit Commun Multiple
### Remarque
$$
PPCM(a,b) = \frac{|ab|}{PGCD(a,b)}
$$
## Propriete
- Soient $(a,b) \in \mathbb{Z}$ non tous nulls, alors :
$$
PGCD(a,b) \times PPCM(a,b) = |ab|
$$
- $\forall (a,b) \in \mathbb{Z}^{2}$
1. $a\mathbb{Z} \cap b\mathbb{Z} = PPCM(a,b)\mathbb{Z}$
2. $a\mathbb{Z} + b\mathbb{Z} = PGCD(a,b)\mathbb{Z}$
# Indicatrice d'Euler
$$
\Phi:
\begin{cases}
\mathbb{N}^{*} \longrightarrow \mathbb{N}^{*} \\
n \longmapsto card\{r \in [|0,n-1|]|n\wedge r = 1 \}
\end{cases}
$$
它的函数值就是 nombre de generateurs de $(\mathbb{Z}/n\mathbb{Z},+)$
我们可以手动计算他值域的前几个值：

|n|1|2|3|4|5|6|7|8|9|10|
|---|---|---|---|---|---|---|---|---|---|---|
|$\Phi(n)$|1|1|2|2|4|2|6|4|6|4|
我们目前还没有算法可以计算出它的所有值。
## Proprietes
- p un nombre premier
$$
\Phi(p) = p-1
$$
- $\forall n \in \mathbb{N}^{*}$, on a:
$$
n = \sum_{d \in [|1,n|],\text{d diviseur de n}}\Phi(d)
$$